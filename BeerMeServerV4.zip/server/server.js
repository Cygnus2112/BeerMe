var express = require('express');
var bodyParser = require('body-parser');
var routes = require('./routes');
var mongoose = require('mongoose');
var app = express();
var db = require('./database');
var request = require('request');

var Promise = require('bluebird');

app.use(function(req,res,next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,POST,PUT');
  res.header('Access-Control-Expose-Headers', 'token');

  next();
});

var port = process.env.PORT || 8080;

app.use(bodyParser.json());

app.use('/', routes);

app.listen(port);

console.log('Listening on port ' + port);

module.exports = app;


